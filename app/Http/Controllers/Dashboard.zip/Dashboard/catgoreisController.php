<?php

namespace App\Http\Controllers\Dashboard;


use App\Models\Carcolors;
use App\Models\Catgories;
use App\Traits\GeneralTrait;
use App\Traits\imageTrait;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class catgoreisController extends Controller
{
    use imageTrait;

    public function index(Request $request)
    {
        $allCatgories = Catgories::when($request->search, function ($query) use ($request) {

            return $query->where('name_ar', 'like', '%' . $request->search . '%')
                ->orWhere('name_en', 'like', '%' . $request->search . '%');

        })->paginate(10);

        return view('dashboard.catgoires.index', compact('allCatgories'));

    }


    public function create()
    {
        $catgory=Catgories::all()->where('parent_id','=',null);
        return view('dashboard.catgoires.add',compact('catgory'));
    }


    public function store(Request $request)
    {
        $request->validate([
            'name_ar' => 'required',
            'name_en' => 'required',
        ]);
         if ($request->parent_id=='null'){
             $request_date=$request->except('_token','parent_id','img');
             $image=$this->storeImages($request->img,'uploads/catgoires/');
             $request_date['img']=$image;
             $catgory=Catgories::create($request_date);
         }else{
             $request_date=$request->except('_token','img');
             $catgory=Catgories::create($request_date);
         }


        session()->flash('success', __('site.added_successfully'));
        return redirect()->route('dashboard.catgoiries.index');
    }


    public function show($Catgories)
    {
        $status=DB::table('catgoiries')->where('id',$Catgories)->value('active');
        if ($status==1){
            $about=DB::table('catgoiries')->where('id',$Catgories)->update(['active'=>0]);
            session()->flash('success', __('site.updated_successfully'));
            return redirect()->route('dashboard.catgoiries.index');
        }else{
            $about=DB::table('catgoiries')->where('id',$Catgories)->update(['active'=>1]);
            session()->flash('success', __('site.updated_successfully'));
            return redirect()->route('dashboard.catgoiries.index');
        }

    }


    public function edit($Catgories)
    {
         $catgory=Catgories::all()->where('parent_id','=',null);
        $catgoiry=Catgories::find($Catgories);
         return view('dashboard.catgoires.update', compact('catgory','catgoiry'));
    }


    public function update(Request $request,$Catgories)
    {
        $request->validate([
            'name_ar' => 'required',
            'name_en' => 'required',
        ]);
        $catgorirs=Catgories::find($Catgories);
        if ($request->parent_id=='null'){
            $request_date=$request->except('_token','parent_id','img');
            $image=$this->storeImages($request->img,'uploads/catgoires/');
            $request_date['img']=$image;
            $Catgories=$catgorirs->update($request_date);
        }else{
            $request_date=$request->except('_token','img');
            $Catgories=$catgorirs->update($request_date);
        }

        session()->flash('success', __('site.updated_successfully'));
        return redirect()->route('dashboard.catgoiries.index');
    }

    public function destroy($Catgories)
    {
       Catgories::destroy($Catgories);
        session()->flash('success', __('site.deleted_successfully'));
        return redirect()->route('dashboard.catgoiries.index');
    }
}
