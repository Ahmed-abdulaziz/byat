<?php

namespace App\Http\Controllers\Dashboard;

use App\Models\Carshapes;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class CaeShapesControler extends Controller
{

    public function index(Request $request)
    {
        $allCatgories = Carshapes::when($request->search, function ($query) use ($request) {

            return $query->where('name_ar', 'like', '%' . $request->search . '%')
                ->orWhere('name_en', 'like', '%' . $request->search . '%');

        })->latest()->paginate(5);
        return view('dashboard.carshapes.index', compact('allCatgories'));
    }


    public function create()
    {
        return view('dashboard.carshapes.add');
    }


    public function store(Request $request)
    {
        $request->validate([
            'name_ar'=>'required',
            'name_en'=>'required',

        ]);

        $date=$request->except('_token');
        $brand=Carshapes::create($date);
        if ($brand){

            session()->flash('success', __('site.added_successfully'));
            return redirect()->route('dashboard.carshapes.index');
        }
    }


    public function show(Carshapes $carshapes)
    {
        //
    }


    public function edit($carshapes)
    {
        $catgoiry=Carshapes::find($carshapes);
        return view('dashboard.carshapes.update', compact('catgoiry'));
    }


    public function update(Request $request,$carshapes)
    {
        $request->validate([
            'name_ar'=>'required',
            'name_en'=>'required',

        ]);
        $date=$request->except('_token');
        $catgoiry=Carshapes::find($carshapes);
        $brand=$catgoiry->update($date);
        if ($brand){

            session()->flash('success', __('site.updated_successfully'));
            return redirect()->route('dashboard.carshapes.index');
        }
    }


    public function destroy( $carshapes)
    {
        $destory=Carshapes::destroy($carshapes);
        session()->flash('success', __('site.deleted_successfully'));
        return redirect()->route('dashboard.carshapes.index');
    }
}
