<?php

namespace App\Http\Controllers\Dashboard;


use App\Models\carBrands;
use App\Models\carModels;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class carTypeController extends Controller
{

    public function index(Request $request)
    {
        $allCatgories = carModels::when($request->search, function ($query) use ($request) {

            return $query->where('name_ar', 'like', '%' . $request->search . '%')
                ->orWhere('name_en', 'like', '%' . $request->search . '%');

        })->latest()->paginate(5);

        return view('dashboard.cartype.index', compact('allCatgories'));
    }


    public function create()
    {
        $catgory=carBrands  ::all();
        return view('dashboard.cartype.add',compact('catgory'));
    }


    public function store(Request $request)
    {
     $request->validate([
            'brand_id'=>'required',
            'name_ar'=>'required',
            'name_en'=>'required',
     ]);

     $date=$request->except('_token');
     $cartype=carModels::create($date);
     if($cartype){
         session()->flash('success', __('site.added_successfully'));
         return redirect()->route('dashboard.cartype.index');
     }


    }


    public function show(carModels $carsTypes)
    {
        //
    }


    public function edit($carsTypes)
    {
        $cartype=carModels::find($carsTypes);
        $catgory=carBrands::all();
        return view('dashboard.cartype.update',compact('catgory','cartype'));
    }


    public function update(Request $request,$carsTypes)
    {
        $request->validate([
            'brand_id'=>'required',
            'name_ar'=>'required',
            'name_en'=>'required',
        ]);
        $date=$request->except('_token');
        $catgoiry=carModels::find($carsTypes);
        $brand=$catgoiry->update($date);
        if ($brand){

            session()->flash('success', __('site.updated_successfully'));
            return redirect()->route('dashboard.cartype.index');
        }

    }


    public function destroy($carsTypes)
    {
        $catgoiry=carModels::destroy($carsTypes);
        if ($catgoiry){
            session()->flash('success', __('site.deleted_successfully'));
            return redirect()->route('dashboard.cartype.index');
        }

    }
}
