<?php

namespace App\Http\Controllers\Dashboard;

use App\Models\Carstatus;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class CarStatusController extends Controller
{

    public function index(Request $request)
    {
        $allCatgories = Carstatus::when($request->search, function ($query) use ($request) {

            return $query->where('name_ar', 'like', '%' . $request->search . '%')
                ->orWhere('name_en', 'like', '%' . $request->search . '%');

        })->latest()->paginate(5);
        return view('dashboard.carstatus.index', compact('allCatgories'));
    }


    public function create()
    {
        return view('dashboard.carstatus.add');
    }


    public function store(Request $request)
    {
        $request->validate([
            'name_ar'=>'required',
            'name_en'=>'required',

        ]);

        $date=$request->except('_token');
        $brand=Carstatus::create($date);
        if ($brand){

            session()->flash('success', __('site.added_successfully'));
            return redirect()->route('dashboard.carstatus.index');
        }

    }


    public function show(Carstatus $carstatus)
    {
        //
    }


    public function edit( $carstatus)
    {
        $catgoiry=Carstatus::find($carstatus);
        return view('dashboard.carstatus.update', compact('catgoiry'));
    }


    public function update(Request $request,  $carstatus)
    {
        $request->validate([
            'name_ar'=>'required',
            'name_en'=>'required',

        ]);
        $date=$request->except('_token');
        $catgoiry=Carstatus::find($carstatus);
        $brand=$catgoiry->update($date);
        if ($brand){

            session()->flash('success', __('site.updated_successfully'));
            return redirect()->route('dashboard.carstatus.index');
        }
    }

    public function destroy($carstatus)
    {
        $destory=Carstatus::destroy($carstatus);
        session()->flash('success', __('site.deleted_successfully'));
        return redirect()->route('dashboard.carstatus.index');
    }
}
