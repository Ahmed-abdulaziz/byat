<?php

namespace App\Http\Controllers\Dashboard;


use App\Models\Carfules;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class CaeFulesControler extends Controller
{

    public function index(Request $request)
    {
        $allCatgories =Carfules::when($request->search, function ($query) use ($request) {

            return $query->where('name_ar', 'like', '%' . $request->search . '%')
                ->orWhere('name_en', 'like', '%' . $request->search . '%');

        })->latest()->paginate(5);
        return view('dashboard.carfules.index', compact('allCatgories'));
    }


    public function create()
    {
        return view('dashboard.carfules.add');
    }


    public function store(Request $request)
    {
        $request->validate([
            'name_ar'=>'required',
            'name_en'=>'required',

        ]);

        $date=$request->except('_token');
        $brand=Carfules::create($date);
        if ($brand){

            session()->flash('success', __('site.added_successfully'));
            return redirect()->route('dashboard.carfules.index');
        }
    }


    public function show(Carfules $carfules)
    {
        //
    }


    public function edit($carfules)
    {
        $catgoiry=Carfules::find($carfules);
        return view('dashboard.carfules.update', compact('catgoiry'));
    }


    public function update(Request $request,$carfules)
    {
        $request->validate([
            'name_ar'=>'required',
            'name_en'=>'required',

        ]);
        $date=$request->except('_token');
        $catgoiry=Carfules::find($carfules);
        $brand=$catgoiry->update($date);
        if ($brand){

            session()->flash('success', __('site.updated_successfully'));
            return redirect()->route('dashboard.carfules.index');
        }
    }


    public function destroy( $carfules)
    {
        $destory=Carfules::destroy($carfules);
        session()->flash('success', __('site.deleted_successfully'));
        return redirect()->route('dashboard.carfules.index');
    }
}
