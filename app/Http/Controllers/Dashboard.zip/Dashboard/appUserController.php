<?php

namespace App\Http\Controllers\Dashboard;

use App\Models\appUsers;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class appUserController extends Controller
{

    public function index(Request $request)
    {
        $Bankacounts = appUsers::when($request->search, function ($query) use ($request) {

            return $query->where('name_ar', 'like', '%' . $request->search . '%')
                ->orWhere('name_en', 'like', '%' . $request->search . '%');

        })->latest()->paginate(5);

        return view('dashboard.appuser.index', compact('Bankacounts'));

    }


    public function create()
    {

    }


    public function store(Request $request)
    {

    }


    public function show($appUsers)
    {
        $status=DB::table('app_users')->where('id',$appUsers)->value('suspend');
        if ($status==1){
            $about=DB::table('app_users')->where('id',$appUsers)->update(['suspend'=>0]);
            session()->flash('success', __('site.updated_successfully'));
            return redirect()->route('dashboard.appuser.index');
        }else{
            $about=DB::table('app_users')->where('id',$appUsers)->update(['suspend'=>1]);
            session()->flash('success', __('site.updated_successfully'));
            return redirect()->route('dashboard.appuser.index');
        }
    }


    public function edit($appUsers)
    {
        return view('dashboard.appuser.update',compact('appUsers'));
    }


    public function update(Request $request,$appUsers)
    {
        $request->validate([
            'adv_number'=>'required'
        ]);
       $date=$request->except('_token');


          $update=appUsers::find($appUsers);

        $update->update($date);
        session()->flash('success', __('site.updated_successfully'));
        return redirect()->route('dashboard.appuser.index');

    }


    public function destroy($appUsers)
    {
        $appuser=appUsers::destroy($appUsers);
        session()->flash('success', __('site.deleted_successfully'));
        return redirect()->route('dashboard.appuser.index');
    }
}
