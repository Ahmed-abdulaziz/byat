<?php

namespace App\Http\Controllers\Dashboard;

use App\Traits\notifcationTrait;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class sendGenralNotfications extends Controller
{
    use notifcationTrait;
    public function index(){
       return view('dashboard.genralNotfication.add');
    }
    public function sendnotifaction(Request $request){
         $this->broadCastNotification('Iqbay',$request->notifcatoion,'IqbayTopic');
        return redirect()->route('dashboard.getnotifview')->with(['success'=>'تم ارسال الاشعار']);
    }
}
