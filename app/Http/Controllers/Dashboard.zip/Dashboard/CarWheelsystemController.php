<?php

namespace App\Http\Controllers\Dashboard;

use App\Models\Carstatus;
use App\Models\Carwheelsystem;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class CarWheelsystemController extends Controller
{

    public function index(Request $request)
    {
        $allCatgories = Carwheelsystem::when($request->search, function ($query) use ($request) {

            return $query->where('name_ar', 'like', '%' . $request->search . '%')
                ->orWhere('name_en', 'like', '%' . $request->search . '%');

        })->latest()->paginate(5);
        return view('dashboard.carwhealsystem.index', compact('allCatgories'));
    }


    public function create()
    {
        return view('dashboard.carwhealsystem.add');
    }


    public function store(Request $request)
    {
        $request->validate([
            'name_ar'=>'required',
            'name_en'=>'required',

        ]);

        $date=$request->except('_token');
        $brand=Carwheelsystem::create($date);
        if ($brand){

            session()->flash('success', __('site.added_successfully'));
            return redirect()->route('dashboard.carwhealsystem.index');
        }

    }


    public function show(Carstatus $carstatus)
    {
        //
    }


    public function edit( $carstatus)
    {
        $catgoiry=Carwheelsystem::find($carstatus);
        return view('dashboard.carwhealsystem.update', compact('catgoiry'));
    }


    public function update(Request $request,  $carstatus)
    {
        $request->validate([
            'name_ar'=>'required',
            'name_en'=>'required',

        ]);
        $date=$request->except('_token');
        $catgoiry=Carwheelsystem::find($carstatus);
        $brand=$catgoiry->update($date);
        if ($brand){

            session()->flash('success', __('site.updated_successfully'));
            return redirect()->route('dashboard.carwhealsystem.index');
        }
    }

    public function destroy($carstatus)
    {
        $destory=Carwheelsystem::destroy($carstatus);
        session()->flash('success', __('site.deleted_successfully'));
        return redirect()->route('dashboard.carwhealsystem.index');
    }
}
