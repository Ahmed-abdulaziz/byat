<?php

namespace App\Http\Controllers\Dashboard;

use App\Models\Packages;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class packagesContollerController extends Controller
{

    public function index(Request $request)
    {
        $allCatgories =Packages::when($request->search, function ($query) use ($request) {

            return $query->where('name_ar', 'like', '%' . $request->search . '%')
                ->orWhere('name_en', 'like', '%' . $request->search . '%');

        })->paginate(5);

        return view('dashboard.packages.index', compact('allCatgories'));
    }


    public function create()
    {
        return view('dashboard.packages.add');
    }


    public function store(Request $request)
    {
        $request->validate([
            'name_ar'           =>      'required',
            'name_en'           =>      'required',
            'price'             =>      'required',
            'type'              =>      'required',
            'period'              =>      'required',
        ]);

      if ($request->type==0){
          $request->validate([
              'adv_num'           =>      'required|numeric',
          ]);
       $data=$request->except('_token');
       $save=Packages::create($data);
       session()->flash(__('site.added_successfully'));
       return redirect()->route('dashboard.packages.index');

      }elseif ($request->type==1){
          $request->validate([
              'period'           =>      'required|numeric',
          ]);
          $data=$request->except('_token','adv_num','period');
          $save=Packages::create($data);
          session()->flash(__('site.added_successfully'));
          return redirect()->route('dashboard.packages.index');
      }
    }


    public function show(Packages $packages)
    {

    }


    public function edit($packages)
    {
        $packages=Packages::find($packages);
        return view('dashboard.packages.update',compact('packages'));
    }


    public function update(Request $request,$packages)
    {
        $packages=Packages::find($packages);
        $date=$request->except('_token');
        $packages->update($date);
        session()->flash(__('site.updated_successfully'));
        return redirect()->route('dashboard.packages.index');
    }


    public function destroy($packages)
    {
          Packages::destroy($packages);;
          session()->flash(__('site.added_successfully'));
          return redirect()->route('dashboard.packages.index');

    }
}
