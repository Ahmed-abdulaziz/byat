<?php

namespace App\Http\Controllers\Dashboard;

use App\Models\Carcolors;
use App\Models\Carstatus;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class CarcolorsController extends Controller
{

    public function index(Request $request)
    {
        $allCatgories = Carcolors::when($request->search, function ($query) use ($request) {

            return $query->where('name_ar', 'like', '%' . $request->search . '%')
                ->orWhere('name_en', 'like', '%' . $request->search . '%');

        })->latest()->paginate(5);
        return view('dashboard.carcolors.index', compact('allCatgories'));
    }


    public function create()
    {
        return view('dashboard.carcolors.add');
    }


    public function store(Request $request)
    {
        $request->validate([
            'name_ar'=>'required',
            'name_en'=>'required',

        ]);

        $date=$request->except('_token');
        $brand=Carcolors::create($date);
        if ($brand){

            session()->flash('success', __('site.added_successfully'));
            return redirect()->route('dashboard.carcolors.index');
        }

    }


    public function show(Carcolors $carcolors)
    {
        //
    }


    public function edit( $carcolors)
    {
        $catgoiry=Carcolors::find($carcolors);
        return view('dashboard.carcolors.update', compact('catgoiry'));
    }


    public function update(Request $request, $carcolors)
    {
        $request->validate([
            'name_ar'=>'required',
            'name_en'=>'required',

        ]);
        $date=$request->except('_token');
        $catgoiry=Carcolors::find($carcolors);
        $brand=$catgoiry->update($date);
        if ($brand){

            session()->flash('success', __('site.updated_successfully'));
            return redirect()->route('dashboard.carcolors.index');
        }
    }


    public function destroy($carcolors)
    {
        $destory=Carcolors::destroy($carcolors);
        session()->flash('success', __('site.deleted_successfully'));
        return redirect()->route('dashboard.carcolors.index');
    }
}
