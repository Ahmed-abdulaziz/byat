<?php

namespace App\Http\Controllers\Dashboard;

use App\Models\Cardoors;
use App\Models\Carseats;
use App\Models\Carstatus;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class CarSeatsnumbersController extends Controller
{

    public function index(Request $request)
    {
        $allCatgories = Carseats::when($request->search, function ($query) use ($request) {

            return $query->where('numbers', 'like', '%' . $request->search . '%');


        })->latest()->paginate(5);
        return view('dashboard.carseatsnumbers.index', compact('allCatgories'));
    }


    public function create()
    {
        return view('dashboard.carseatsnumbers.add');
    }


    public function store(Request $request)
    {
        $request->validate([
            'numbers'=>'required|numeric',
        ]);

        $date=$request->except('_token');
        $brand=Carseats::create($date);
        if ($brand){

            session()->flash('success', __('site.added_successfully'));
            return redirect()->route('dashboard.carseatsnumbers.index');
        }

    }


    public function show(Carstatus $carstatus)
    {
        //
    }


    public function edit( $carstatus)
    {
        $catgoiry=Carseats::find($carstatus);
        return view('dashboard.carseatsnumbers.update', compact('catgoiry'));
    }


    public function update(Request $request,  $carstatus)
    {
        $request->validate([
            'numbers'=>'required|numeric',

        ]);
        $date=$request->except('_token');
        $catgoiry=Carseats::find($carstatus);
        $brand=$catgoiry->update($date);
        if ($brand){

            session()->flash('success', __('site.updated_successfully'));
            return redirect()->route('dashboard.carseatsnumbers.index');
        }
    }

    public function destroy($carstatus)
    {
        $destory=Carseats::destroy($carstatus);
        session()->flash('success', __('site.deleted_successfully'));
        return redirect()->route('dashboard.carseatsnumbers.index');
    }
}
