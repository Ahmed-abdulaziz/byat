<?php

namespace App\Http\Controllers\Dashboard;

use App\Models\Cardoors;
use App\Models\Carstatus;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class CarDoorsnumbersController extends Controller
{

    public function index(Request $request)
    {
        $allCatgories = Cardoors::when($request->search, function ($query) use ($request) {

            return $query->where('numbers', 'like', '%' . $request->search . '%');


        })->latest()->paginate(5);
        return view('dashboard.cardoorsnumbers.index', compact('allCatgories'));
    }


    public function create()
    {
        return view('dashboard.cardoorsnumbers.add');
    }


    public function store(Request $request)
    {
        $request->validate([
            'numbers'=>'required|numeric',
        ]);

        $date=$request->except('_token');
        $brand=Cardoors::create($date);
        if ($brand){

            session()->flash('success', __('site.added_successfully'));
            return redirect()->route('dashboard.cardoorsnumbers.index');
        }

    }


    public function show(Carstatus $carstatus)
    {
        //
    }


    public function edit( $carstatus)
    {
        $catgoiry=Cardoors::find($carstatus);
        return view('dashboard.cardoorsnumbers.update', compact('catgoiry'));
    }


    public function update(Request $request,  $carstatus)
    {
        $request->validate([
            'numbers'=>'required|numeric',

        ]);
        $date=$request->except('_token');
        $catgoiry=Cardoors::find($carstatus);
        $brand=$catgoiry->update($date);
        if ($brand){

            session()->flash('success', __('site.updated_successfully'));
            return redirect()->route('dashboard.cardoorsnumbers.index');
        }
    }

    public function destroy($carstatus)
    {
        $destory=Cardoors::destroy($carstatus);
        session()->flash('success', __('site.deleted_successfully'));
        return redirect()->route('dashboard.cardoorsnumbers.index');
    }
}
