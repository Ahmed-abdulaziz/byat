<?php

namespace App\Http\Controllers\Dashboard;

use App\Models\advertiseComeents;
use App\Models\Advertisments;
use App\Models\Advimages;
use App\Models\advretisements;

use App\Models\appSettings;
use App\Models\appUsers;
use App\Models\banAdvertisment;
use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class advController extends Controller
{

    public function index(Request $request)
    {
        $Bankacounts = Advertisments::when($request->search, function ($query) use ($request) {

            return $query->where('titile', 'like', '%' . $request->search . '%')
                ->orWhere('titile', 'like', '%' . $request->search . '%');

        })->latest()->paginate(5);

        return view('dashboard.advertismnets.index', compact('Bankacounts'));

    }


    public function create()
    {
        $aboutapp=appSettings::select('id','adv_date')->get();;
        return view('dashboard.advdate.index', compact('aboutapp'));
    }


    public function store(Request $request)
    {

    }


    public function show($advretisements)
    {
        $status=DB::table('advretisements')->where('id',$advretisements)->value('active');
        if ($status==1){
            $about=DB::table('advretisements')->where('id',$advretisements)->update(['active'=>0]);
            session()->flash('success', __('site.updated_successfully'));
            return redirect()->route('dashboard.advertismnets.index');
        }else{
            $about=DB::table('advretisements')->where('id',$advretisements)->update(['active'=>1]);
            session()->flash('success', __('site.updated_successfully'));
            return redirect()->route('dashboard.advertismnets.index');
        }
    }



    public function edit($advretisements)
    {
        $iamges=Advimages::all()->where('adv_id','=',$advretisements);
        return view('dashboard.advertismnets.index2',compact('iamges'));
    }


    public function update(Request $request,$advretisements)
    {
        $request->validate([
            'adv_date'=>'required'
        ]);
        $about=DB::table('app_settings')->where('id',$advretisements)->update(['adv_date'=>$request->adv_date]);
        session()->flash('success', __('site.updated_successfully'));
        return redirect()->route('dashboard.advertismnets.create');
    }

    public function destroy($advretisements)
    {
        $del=Advertisments::destroy($advretisements);

        session()->flash('success', __('site.deleted_successfully'));
        return redirect()->route('dashboard.advertismnets.index');
    }




}
