<?php

namespace App\Http\Controllers\Dashboard;


use App\Models\Cartransmission;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class carTransmitionController extends Controller
{

    public function index(Request $request)
    {
        $allCatgories = Cartransmission::when($request->search, function ($query) use ($request) {

            return $query->where('name_ar', 'like', '%' . $request->search . '%')
                ->orWhere('name_en', 'like', '%' . $request->search . '%');

        })->latest()->paginate(5);
        return view('dashboard.cartranmtion.index', compact('allCatgories'));
    }


    public function create()
    {
        return view('dashboard.cartranmtion.add');
    }


    public function store(Request $request)
    {
        $request->validate([
            'name_ar'=>'required',
            'name_en'=>'required',

        ]);

        $date=$request->except('_token');
        $brand=Cartransmission::create($date);
        if ($brand){

            session()->flash('success', __('site.added_successfully'));
            return redirect()->route('dashboard.cartranmtion.index');
        }
    }


    public function show(cartranmtion $cartranmtion)
    {
        //
    }


    public function edit($cartranmtion)
    {
        $catgoiry=Cartransmission::find($cartranmtion);
        return view('dashboard.cartranmtion.update', compact('catgoiry'));
    }


    public function update(Request $request,$cartranmtion)
    {
        $request->validate([
            'name_ar'=>'required',
            'name_en'=>'required',

        ]);
        $date=$request->except('_token');
        $catgoiry=Cartransmission::find($cartranmtion);
        $brand=$catgoiry->update($date);
        if ($brand){

            session()->flash('success', __('site.updated_successfully'));
            return redirect()->route('dashboard.cartranmtion.index');
        }
    }


    public function destroy( $cartranmtion)
    {
        $destory=Cartransmission::destroy($cartranmtion);
        $destory=Cartransmission::destroy($cartranmtion);
        session()->flash('success', __('site.deleted_successfully'));
        return redirect()->route('dashboard.cartranmtion.index');
    }
}
