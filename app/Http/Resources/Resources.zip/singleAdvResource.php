<?php

namespace App\Http\Resources;

use App\Models\Advimages;
use App\Models\appUsers;
use App\Models\area;
use App\Models\carBrands;
use App\Models\Carcolors;
use App\Models\Cardoors;
use App\Models\Carenginetype;
use App\Models\Carfules;
use App\Models\carModels;
use App\Models\Carseats;
use App\Models\Carshapes;
use App\Models\Carstatus;
use App\Models\Cartransmission;
use App\Models\Carwheelsystem;
use App\Models\Catgories;
use App\Models\city;
use App\Models\realstateperiod;
use App\Models\realstatetype;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Facades\DB;

class singleAdvResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        $imgs=Advimages::all()->where('adv_id','=',$this->id);
        $images=advimagesResource::collection($imgs);
        $fav=DB::table('favoritesadvs')->where('user_id','=',$this->check_id)->where('adv_id','=',$this->id)->where('status','=',1)->count();
        if ($fav==0){
            $favx=0;
        }else{
            $favx=1;
        }
        $cat=new CatgeoryResouce(Catgories::find($this->cat_id));
        $subcat=new CatgeoryResouce(Catgories::find($this->sub_id));
        if ($subcat){
            $sub=$subcat;
        }else{
            $sub=(object)[];
        }
        $user=new SingleAdvuserData(appUsers::find($this->user_id));

        if ($this->type==0){
            $brand=carBrands::find($this->brand_id);
            $model=carModels::find($this->model_id);
            $status=Carstatus::find($this->status_id);
            $color=Carcolors::find($this->color_id);
            $shape=Carshapes::find($this->shape_id);
            $cardoors=Cardoors::find($this->door_number);
            $carseats=Carseats::find($this->seat_number);
            $transmation=Cartransmission::find($this->cartransmissions_id);
            $fuel=Carfules::find($this->fueltype_id);
            $whealsyatem=Carwheelsystem::find($this->whealsystemtype);
            $enginetype=Carenginetype::find($this->carenginetype_id);
            $city=city::find($this->city_id);
            $area=area::find($this->area_id);
            if (app()->getLocale()=='ar'){
                $brandname=$brand->name_ar;
                $modelname=$model->name_ar;
                $statusname=$status->name_ar;
                $colorname=$color->name_ar;
                $shapename=$shape->name_ar;
                $transmationname=$transmation->name_ar;
                $fuelname=$fuel->name_ar;
                $whealsyatemname=$whealsyatem->name_ar;
                $enginetypename=$enginetype->name_ar;
                $cityname=$city->name_ar;
                $areaname=$area->name_ar;

            }else{
                $brandname=$brand->name_en;
                $modelname=$model->name_en;
                $statusname=$status->name_en;
                $colorname=$color->name_en;
                $shapename=$shape->name_en;
                $transmationname=$transmation->name_en;
                $fuelname=$fuel->name_en;
                $whealsyatemname=$whealsyatem->name_en;
                $enginetypename=$enginetype->name_en;
                $cityname=$city->name_en;
                $areaname=$area->name_en;
            }


            return [
                'id'                    =>           $this->id,
                'user_id'               =>           $this->user_id,
                'advertismet_type'      =>           $this->advertismet_type,
                'phone'                 =>           $this->phone,
                'about'                 =>           $this->about,
                'title'                 =>           $this->title,
                'price'                 =>           $this->price,
                'long'                  =>           $this->long,
                'lat'                   =>           $this->lat,
                'cat_id'                =>           $this->cat_id,
                'sub_id'                =>           $this->sub_id,
                'city_id'               =>           $this->city_id,
                'cityname'              =>           $cityname ?: '',
                'area_id'               =>           $this->area_id,
                'areaname'              =>           $areaname ?: '' ,
                'brand_id'              =>           $this->brand_id,
                'branname'              =>           $brandname ?: '',
                'model_id'              =>           $this->model_id,
                'modelname'             =>           $modelname ?: '',
                'enginetype_id'         =>           $this->carenginetype_id,
                'engineTypename'        =>           $enginetypename ?: '',
                'whealsystemtype_id'    =>           $this->whealsystemtype,
                'whealsystemname'       =>           $whealsyatemname ?: '',
                'fueltype_id'           =>           $this->fueltype_id,
                'fueltypename'          =>           $fuelname ?: '',
                'cartransmissions_id'   =>           $this->cartransmissions_id,
                'cartransmissionsname'  =>           $transmationname ?: '',
                'color_id'              =>           $this->color_id,
                'colorname'             =>           $colorname ?: '',
                'shape_id'              =>           $this->shape_id,
                'shapename'             =>           $shapename ?: '',
                'status_id'             =>           $this->status_id,
                'statusname'            =>           $statusname ?: '',
                'address'               =>           $this->address,
                'door_number_id'        =>           $cardoors->id,
                'door_number'           =>           $cardoors->numbers,
                'seat_number_id'        =>           $carseats->id,
                'seat_number'           =>           $carseats->numbers,
                'year'                  =>           $this->year,
                'kilometers'            =>           $this->kilometers,
                'type'                  =>           $this->type,
                'special'               =>           $this->special,
                'favourite'             =>           $favx,
                'category'              =>           $cat,
                'subCategory'              =>           $sub,
                'user_info'             =>           $user,
                'created_at'            =>           (integer)strtotime($this->created_at),
                'imgs'                  =>           $images ?: [],
            ];

        }elseif ($this->type==1){
            $realstatetype=realstatetype::find($this->realstattype_id);
            $realstatperiod_id=realstateperiod::find($this->realstatperiod_id);
            $city=city::find($this->city_id);
            $area=area::find($this->area_id);
            if (app()->getLocale()=='ar'){
                $realstattypename=$realstatetype->name_ar;
                $realstatperiodname=$realstatperiod_id->name_ar;
                $cityname=$city->name_ar;
                $areaname=$area->name_ar;
            }else{
                $realstattypename=$realstatetype->name_en;
                $realstatperiodname=$realstatperiod_id->name_en;
                $cityname=$city->name_en;
                $areaname=$area->name_en;
            }
            $imgs=Advimages::all()->where('adv_id','=',$this->id);
            $images=advimagesResource::collection($imgs);


            return [
                'id'                    =>           $this->id,
                'user_id'               =>           $this->user_id,
                'long'                  =>           $this->long,
                'lat'                   =>           $this->long,
                'phone'                 =>           $this->phone,
                'address'               =>           $this->address,
                'about'                 =>           $this->about,
                'title'                 =>           $this->title,
                'price'                 =>           $this->price,
                'cat_id'                =>           $this->cat_id,
                'sub_id'                =>           $this->sub_id,
                'type'                  =>           $this->type,
                'special'               =>           $this->special,
                'city_id'               =>           $this->city_id,
                'cityname'              =>           $cityname ?: '',
                'area_id'               =>           $this->area_id,
                'areaname'              =>           $areaname ?: '' ,
                'realstattype_id'       =>           $this->realstattype_id,
                'realstattypename'      =>           $realstattypename,
                'realstatperiod_id'     =>           $this->realstatperiod_id,
                'realstatpreiodname'    =>           $realstatperiodname,
                'realstatepurpose'    =>           $this->realstatepurpose ? : 0,
                'roomnumbers'           =>           $this->roomnumber ? : 0,
                'tolietnumber'          =>           $this->tolietnumber,
                'place_area'            =>           $this->placearea,
                'advertismet_type'      =>           $this->advertismet_type,
                'favourite'             =>           $favx,
                'created_at'            =>           (integer)strtotime($this->created_at),
                'category'              =>           $cat,
                'subCategory'              =>           $sub,
                'user_info'             =>           $user,
                'imgs'                  =>           $images ?: [],
            ];
        }else{
            $city=city::find($this->city_id);
            $area=area::find($this->area_id);
            if (app()->getLocale()=='ar'){
                $cityname=$city->name_ar;
                $areaname=$area->name_ar;
            }else{
                $cityname=$city->name_en;
                $areaname=$area->name_en;
            }
            return [
                'id'                    =>           $this->id,
                'user_id'               =>           $this->user_id,
                'long'                  =>           $this->long,
                'lat'                   =>           $this->long,
                'phone'                 =>           $this->phone,
                'address'               =>           $this->address,
                'about'                 =>           $this->about,
                'city_id'               =>           $this->city_id,
                'cityname'              =>           $cityname ?: '',
                'area_id'               =>           $this->area_id,
                'areaname'              =>           $areaname ?: '' ,
                'title'                 =>           $this->title,
                'price'                 =>           $this->price,
                'cat_id'                =>           $this->cat_id,
                'sub_id'                =>           $this->sub_id,
                'type'                  =>           $this->type,
                'special'               =>           $this->special,
                'favourite'             =>           $favx,
                'category'              =>           $cat,
                'subCategory'              =>        $sub,
                'user_info'             =>           $user,
                'created_at'            =>           (integer)strtotime($this->created_at),
                'advertismet_type'      =>           $this->advertismet_type,
            ];
        }
    }
}
