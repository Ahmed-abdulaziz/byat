<?php

namespace App\Http\Resources;

use App\Models\Catgories;
use Illuminate\Http\Resources\Json\JsonResource;

class CatgeoryResouce extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        if (app()->getLocale()=='ar'){
            $name=$this->name_ar;
        }else{
            $name=$this->name_en;
        }
        $subs=Catgories::all()->where('parent_id','=',$this->id)->count();
        if ($subs==0){
            $sub=0;
        }else{
            $sub=1;
        }

        if ($this->img==null){
          return[
                'id'            =>       $this->id,
                'name'          =>       $name,
            ];
        }else{
            return[
                'id'            =>       $this->id,
                'name'          =>       $name,
                'img'           =>       asset('uploads/catgoires/'.$this->img) ? : asset('uploads/catgoreis/'),
                'has_sub'       =>       $sub,
            ];


        }
    }
}
