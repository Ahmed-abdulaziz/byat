<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class commenctionResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'facebook'=>$this->facebook,
            'twwiter'=>$this->twwiter,
            'instgram'=>$this->instgram,
            'youtube'=>$this->youtube,
            'whatsapp'=>$this->whatsapp,
            'email'=>$this->email,
            'phone'=>$this->phone,
        ];
    }
}
